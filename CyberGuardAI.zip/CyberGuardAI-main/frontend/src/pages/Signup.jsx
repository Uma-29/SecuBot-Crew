import React from 'react';
import SignupForm from '../components/auth/SignupForm';

const Signup = () => {
  return <SignupForm />;
};

export default Signup;
