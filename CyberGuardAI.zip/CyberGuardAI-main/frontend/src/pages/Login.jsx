import React from 'react';
import LoginForm from '../components/auth/LoginForm';

const Login = () => {
  return <LoginForm />;
};

export default Login;
